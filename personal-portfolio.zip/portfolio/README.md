# Personal Portfolio Website

A responsive personal portfolio website built with **HTML5, CSS3, JavaScript**, and **Bootstrap 5**.

## Features

- Fully responsive (mobile-friendly) design
- Smooth scrolling navigation
- Sticky navbar with scroll effects
- About, Skills, Projects, and Contact sections
- Working contact form with client-side validation
- Modern UI with hover animations

## Technologies Used

- HTML5
- CSS3
- JavaScript (ES6+)
- Bootstrap 5
- Font Awesome icons

## How to Run

1. Open `index.html` in any modern web browser.
2. Or use a local server (recommended):

```bash
# Using Python
python -m http.server 8000

# Using VS Code Live Server extension
```

Then visit `http://localhost:8000`

## Customization

- Replace "Your Name" and placeholder content with your details
- Update project images, links, and descriptions
- Change colors in `styles.css` (CSS variables)
- Connect the contact form to a backend service (Formspree, EmailJS, etc.)

## Live Demo

Deploy to GitHub Pages, Netlify, or Vercel for a live link.

---

Made with ❤️ for showcasing projects and skills.
