// Navbar scroll effect
window.addEventListener('scroll', function () {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Active nav link on scroll
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.navbar-nav .nav-link');

window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100;
        if (window.scrollY >= sectionTop) {
            current = section.getAttribute('id');
        }
    });

    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// Smooth close mobile menu on link click
document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
    link.addEventListener('click', () => {
        const navbarCollapse = document.querySelector('.navbar-collapse');
        if (navbarCollapse.classList.contains('show')) {
            const bsCollapse = bootstrap.Collapse.getInstance(navbarCollapse);
            if (bsCollapse) bsCollapse.hide();
        }
    });
});

// Contact form validation & submission
const form = document.getElementById('contactForm');
const formAlert = document.getElementById('formAlert');

form.addEventListener('submit', function (event) {
    event.preventDefault();
    event.stopPropagation();

    if (form.checkValidity()) {
        // Simulate form submission (replace with real backend later)
        formAlert.classList.remove('d-none', 'alert-danger');
        formAlert.classList.add('alert-success');
        formAlert.textContent = 'Thank you! Your message has been sent successfully.';
        form.reset();
        form.classList.remove('was-validated');

        // Hide success message after 5 seconds
        setTimeout(() => {
            formAlert.classList.add('d-none');
        }, 5000);
    } else {
        formAlert.classList.remove('d-none', 'alert-success');
        formAlert.classList.add('alert-danger');
        formAlert.textContent = 'Please fill in all required fields correctly.';
    }

    form.classList.add('was-validated');
});
